# Thank you for your donation!

All your donations will be used for the project maintainment and development. If you want to donate another cryptocurrency please [contact](https://okhlopkov.com).

Bitcoin Address: `18NPJHxK9xuYpHDbjdpWdNGVj2dgo9bLx2`.

![QR code](https://bitref.com/qr.php?data=18NPJHxK9xuYpHDbjdpWdNGVj2dgo9bLx2)
